document.getElementById("languageToggle").addEventListener("click", function () {
    const htmlTag = document.documentElement; // Select <html>
    const navbar = document.getElementById("navbar"); // Select navbar

    if (htmlTag.dir === "ltr" || htmlTag.dir === "") {
        htmlTag.dir = "rtl"; // Switch to right-to-left
        htmlTag.lang = "ar"; // Set language to Arabic
        this.textContent = "English"; // Change button text to English
    } else {
        htmlTag.dir = "ltr"; // Switch back to left-to-right
        htmlTag.lang = "en"; // Set language to English
        this.textContent = "العربية"; // Change button text to Arabic
    }
});
function initializeNavbar() {
    // Toggle Button Logic
    const menuToggle = document.getElementById("menuToggle");
    const navMenu = document.getElementById("navMenu");

    if (menuToggle && navMenu) {
        menuToggle.addEventListener("click", function () {
            navMenu.classList.toggle("active");
        });
    }

    // Language Button Logic
    const languageToggle = document.getElementById("languageToggle");
    if (languageToggle) {
        languageToggle.addEventListener("click", function () {
            alert("Button Clicked!");
        });
    }
}

function loadNavbar() {
    // Fetch and insert navbar
    fetch("navbar.html")
        .then(response => response.text())
        .then(data => {
            document.getElementById("navbar").innerHTML = data;
            initializeNavbar(); // Ensure navbar functionality works after loading
        })
        .catch(error => console.error("Error loading navbar:", error));
    }

function loadFooter(){
    fetch("footer.html")
        .then((response) => response.text())
        .then((data) => {
          document.getElementById("footer").innerHTML = data;
        })
        .catch((error) => {
          console.error("Error loading navbar:", error);
        });
}